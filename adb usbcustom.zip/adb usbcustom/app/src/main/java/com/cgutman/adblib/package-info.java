/**
 * This package provides a native Java implementation of the ADB protocol.
 * @author Cameron Gutman
 */
package com.cgutman.adblib;
package in.hridayan.ashell.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Handler;
import android.os.Parcelable;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;
import com.cgutman.adblib.AdbBase64;
import com.cgutman.adblib.AdbConnection;
import com.cgutman.adblib.AdbStream;
import in.hridayan.ashell.Message;
import in.hridayan.ashell.config.Const;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;
import com.adbusba.log;
import java.io.DataInput;
import java.io.DataOutput;
import java.nio.charset.Charset;


public class OtgUtils {

  public static class MessageOtg {
    public static final int DEVICE_NOT_FOUND = 0;
    public static final int CONNECTING = 1;
    public static final int DEVICE_FOUND = 2;
    public static final int FLASHING = 3;
    public static final int INSTALLING_PROGRESS = 4;
    public static final int PUSH_PART = 5;
    public static final int PM_INST_PART = 6;
    public static final String USB_PERMISSION = "hridayan.usb.permission";
  }

  public static class ByteUtilsold {

    public static byte[] concat(byte[]... arrays) {
      // Determine the length of the result array
      int totalLength = 0;
      for (int i = 0; i < arrays.length; i++) {
        totalLength += arrays[i].length;
      }

      // create the result array
      byte[] result = new byte[totalLength];

      // copy the source arrays into the result array
      int currentIndex = 0;
      for (int i = 0; i < arrays.length; i++) {
		  currentIndex += 1;
        System.arraycopy(arrays[i], 0, result, currentIndex, arrays[i].length);
        currentIndex += arrays[i].length;
      }

      return result;
    }

    public static final byte[] intToByteArray(int value) {
      return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array();
    }
  }
	public static class ByteUtils {

		public static byte[] concat(byte[]... arrays) {
			// Determine the length of the result array
			int totalLength = 0;
			for (int i = 0; i < arrays.length; i++) {
				totalLength += arrays[i].length;
			}

			// create the result array
			byte[] result = new byte[totalLength];

			// copy the source arrays into the result array
			int currentIndex = 0;
			for (int i = 0; i < arrays.length; i++) {
				//currentIndex += 1;
				System.arraycopy(arrays[i], 0, result, currentIndex, arrays[i].length);
				currentIndex += arrays[i].length;
			}

			return result;
		}

		public static final byte[] intToByteArray(int value) {
			return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array();
		}
	}
  public static class UsbReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
      String action = intent.getAction();
      UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

      if (device == null) return;

      String manufacturer = device.getManufacturerName();
      String product = device.getProductName();
		if (intent!=null && (action = intent.getAction()) !=null && action.equals(UsbManager.ACTION_USB_DEVICE_ATTACHED)){
			Intent intent1 = new Intent(Message.USB_PERMISSION);
			intent1.putExtra(UsbManager.EXTRA_DEVICE, (Parcelable) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE));
			context.sendBroadcast(intent1);
		}
      if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
        //showToast(context, "USB Device Attached: " + manufacturer + " " + product);
      } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
        //showToast(context, "USB Device Detached: " + manufacturer + " " + product);
        //sendIntentUponDetached(context);
		  
      }
    }
    private void showToast(Context context, String message) {
      Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
/*
    private void sendIntentUponDetached(Context context) {
      Intent intent = new Intent(context, MainActivity.class);
      intent.setAction("in.hridayan.ashell.ACTION_USB_DETACHED");
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      context.startActivity(intent);
    }*/
  }

/*  public static class Push {

    private AdbConnection adbConnection;
    private File local;
    private String remotePath;
	Context mcon;
	AdbStream stream;
	
    public Push(Context mcon,AdbConnection adbConnection, File local, String remotePath) {
      this.adbConnection = adbConnection;
      this.local = local;
      this.remotePath = remotePath;
	  this.mcon=mcon;
    }

    public void executeold(Handler handler) throws InterruptedException, IOException {
		//Toast.makeText(mcon,"rereeeerfe",1).show();
      stream = adbConnection.open("sync:");

      String sendId = "SEND";

      String mode = ",0664";

      int length = (remotePath + mode).length();
		
      stream.write(ByteUtils.concat(sendId.getBytes(), ByteUtils.intToByteArray(length)));

		stream.write(remotePath+mode.getBytes());

     // stream.write(mode.getBytes());

      //byte[] buff = new byte[adbConnection.getMaxData()];
	  //byte[] buff = new byte[1024];
	  byte[] buff = new byte[6144];
      FileInputStream is = new FileInputStream(local);
		//mcon.append("0");
      long sent = 0;
      long total = local.length();
      int lastProgress = 0;
      while (true) {
        int read = is.read(buff);
        if (read <= 0) {
			//mcon.append("1");
          break;
        }

		  /*try {
			  ByteBuffer var105 = ByteBuffer.allocate(read + 8);
			  var105.order(ByteOrder.LITTLE_ENDIAN);
			  var105.putInt(mkid('D', 'A', 'T', 'A'));
			  var105.putInt(read);
			  var105.put(Arrays.copyOf(buff, read));
			  var105.flip();
			  stream.write(var105.array());
		  } catch (Throwable var95) {
			  //var10000 = var95;
			//  var10001 = false;
			  break;
		  }*/
		  //stream.write( ByteUtils.intToByteArray(read+8));
		 // mcon.append("2");
/*        stream.write(ByteUtils.concat("DATA".getBytes(), ByteUtils.intToByteArray(read)));

        if (read == buff.length) {
          stream.write(buff);
        } else {
          byte[] tmp = new byte[read];
          System.arraycopy(buff, 0, tmp, 0, read);
          stream.write(tmp);
			//mcon.append("3");
        }
		//  mcon.append("4");
        sent += read;

        final int progress = (int) (sent * 100 / total);
        if (lastProgress != progress) {
          handler.sendMessage(
              handler.obtainMessage(
                  Message.INSTALLING_PROGRESS, Message.PUSH_PART, progress));
          lastProgress = progress;
        }
      }

      stream.write(
          ByteUtils.concat(
              "DONE".getBytes(), ByteUtils.intToByteArray((int) System.currentTimeMillis())));
	//	mcon.append("5");
      byte[] res = stream.read();
      // TODO: test if res contains "OKEY" or "FAIL"
      Log.d(Const.TAG, new String(res));

      stream.write(ByteUtils.concat("QUIT".getBytes(), ByteUtils.intToByteArray(0)));
	//	mcon.append("6");
    }

	
		public void execute(Handler handler) throws InterruptedException, IOException {
			//Toast.makeText(mcon,"rereeeerfe",1).show();
			AdbStream stream = adbConnection.open("sync:");

			String sendId = "SEND";

			String mode = ",33152";

			int length = (remotePath + mode).length();

			stream.write(ByteUtils.concat(sendId.getBytes(), ByteUtils.intToByteArray(length)));

			stream.write(remotePath.getBytes());

			stream.write(mode.getBytes());

			//byte[] buff = new byte[adbConnection.getMaxData()];
			//byte[] buff = new byte[1024];
			byte[] buff = new byte[6144];
			FileInputStream is = new FileInputStream(local);
			//mcon.append("0");
			long sent = 0;
			long total = local.length();
			int lastProgress = 0;
			while (true) {
				int read = is.read(buff);
				if (read <= 0) {
					//mcon.append("1");
					break;
				}

				try {
				 ByteBuffer var105 = ByteBuffer.allocate(read + 8);
				 var105.order(ByteOrder.LITTLE_ENDIAN);
				 var105.putInt(mkid('D', 'A', 'T', 'A'));
				 var105.putInt(read);
				 var105.put(Arrays.copyOf(buff, read));
				 var105.flip();
				 stream.write(var105.array());
				 } catch (Throwable var95) {
				 //var10000 = var95;
				 //  var10001 = false;
				 break;
				 }
				//stream.write( ByteUtils.intToByteArray(read+8));
				// mcon.append("2");
				stream.write(ByteUtils.concat("DATA".getBytes(), ByteUtils.intToByteArray(read)));

				if (read == buff.length) {
					stream.write(buff);
				} else {
					byte[] tmp = new byte[read];
					System.arraycopy(buff, 0, tmp, 0, read);
					stream.write(tmp);
					//mcon.append("3");
				}
				//  mcon.append("4");
				sent += read;

				final int progress = (int) (sent * 100 / total);
				if (lastProgress != progress) {
					handler.sendMessage(
						handler.obtainMessage(
							Message.INSTALLING_PROGRESS, Message.PUSH_PART, progress));
					lastProgress = progress;
				}
			}

			stream.write(
				ByteUtils.concat(
					"DONE".getBytes(), ByteUtils.intToByteArray((int) System.currentTimeMillis())));
			//	mcon.append("5");
			byte[] res = stream.read();
			// TODO: test if res contains "OKEY" or "FAIL"
			Log.d(Const.TAG, new String(res));

			stream.write(ByteUtils.concat("QUIT".getBytes(), ByteUtils.intToByteArray(0)));
			//	mcon.append("6");
		}
		private final int mkid(char var1, char var2, char var3, char var4) {
			return var1 | var2 << 8 | var3 << 16 | var4 << 24;
		}
  }
  */
	public static class Pushnew {

		private AdbConnection adbConnection;
		private File local;
		private String remotePath;
		Context mcon;
		AdbStream stream;

		public Pushnew(Context mcon,AdbConnection adbConnection, File local, String remotePath) {
			this.adbConnection = adbConnection;
			this.local = local;
			this.remotePath = remotePath;
			this.mcon=mcon;
		}

		/*public void executeold(Handler handler) throws InterruptedException, IOException {
			//Toast.makeText(mcon,"rereeeerfe",1).show();
			stream = adbConnection.open("sync:");

			String sendId = "SEND";

			String mode = ",0664";

			int length = (remotePath + mode).length();

			stream.write(ByteUtils.concat(sendId.getBytes(), ByteUtils.intToByteArray(length)));

			stream.write(remotePath+mode.getBytes());

			// stream.write(mode.getBytes());

			//byte[] buff = new byte[adbConnection.getMaxData()];
			//byte[] buff = new byte[1024];
			byte[] buff = new byte[6144];
			FileInputStream is = new FileInputStream(local);
			//mcon.append("0");
			long sent = 0;
			long total = local.length();
			int lastProgress = 0;
			while (true) {
				int read = is.read(buff);
				if (read <= 0) {
					//mcon.append("1");
					break;
				}

				/*try {
				 ByteBuffer var105 = ByteBuffer.allocate(read + 8);
				 var105.order(ByteOrder.LITTLE_ENDIAN);
				 var105.putInt(mkid('D', 'A', 'T', 'A'));
				 var105.putInt(read);
				 var105.put(Arrays.copyOf(buff, read));
				 var105.flip();
				 stream.write(var105.array());
				 } catch (Throwable var95) {
				 //var10000 = var95;
				 //  var10001 = false;
				 break;
				 }*/
				//stream.write( ByteUtils.intToByteArray(read+8));
				// mcon.append("2");
	/*			stream.write(ByteUtils.concat("DATA".getBytes(), ByteUtils.intToByteArray(read)));

				if (read == buff.length) {
					stream.write(buff);
				} else {
					byte[] tmp = new byte[read];
					System.arraycopy(buff, 0, tmp, 0, read);
					stream.write(tmp);
					//mcon.append("3");
				}
				//  mcon.append("4");
				sent += read;

				final int progress = (int) (sent * 100 / total);
				if (lastProgress != progress) {
					handler.sendMessage(
						handler.obtainMessage(
							Message.INSTALLING_PROGRESS, Message.PUSH_PART, progress));
					lastProgress = progress;
				}
			}

			stream.write(
				ByteUtils.concat(
					"DONE".getBytes(), ByteUtils.intToByteArray((int) System.currentTimeMillis())));
			//	mcon.append("5");
			byte[] res = stream.read();
			// TODO: test if res contains "OKEY" or "FAIL"
			Log.d(Const.TAG, new String(res));

			stream.write(ByteUtils.concat("QUIT".getBytes(), ByteUtils.intToByteArray(0)));
			//	mcon.append("6");
		}*/


		public void execute(Handler handler)  {
			//Toast.makeText(mcon,"rereeeerfe",1).show();
			try{
			 stream = adbConnection.open("sync:");
		/*		FileInputStream is = new FileInputStream(local);
			String sendId = "SEND";

			String mode = ",0644";

			int length = (remotePath + mode).length();

			stream.write(ByteUtils.concat(sendId.getBytes(), ByteUtils.intToByteArray(length)));

			stream.write(remotePath.getBytes());

			stream.write(mode.getBytes());

			//byte[] buff = new byte[adbConnection.getMaxData()];
			//byte[] buff = new byte[1024];
			byte[] buff = new byte[1024 * 64];
			
			//mcon.append("0");
			long sent = 0;
			long total = local.length();
			int lastProgress = 0;
			int i=0;
			while (true) {
				i++;
				log.a(stream.isClosed());
				log.a(i);
				int read = is.read(buff);
				if (read <= 0) {
					log.a("break");
					stream.write(
						ByteUtils.concat(
							"DONE".getBytes(), ByteUtils.intToByteArray((int) System.currentTimeMillis())));
					//	mcon.append("5");
					log.a("done");
					byte[] res = stream.read();
					// TODO: test if res contains "OKEY" or "FAIL"
					Log.d(Const.TAG, new String(res));

					stream.write(ByteUtils.concat("QUIT".getBytes(), ByteUtils.intToByteArray(0)));
					//	mcon.append("6");
				
				
					//mcon.append("1");
					break;
					//continue;
				}

				/*try {
					ByteBuffer var105 = ByteBuffer.allocate(read + 8);
					var105.order(ByteOrder.LITTLE_ENDIAN);
					var105.putInt(mkid('D', 'A', 'T', 'A'));
					var105.putInt(read);
					var105.put(Arrays.copyOf(buff, read));
					var105.flip();
					stream.write(var105.array());
				} catch (Throwable var95) {
					//var10000 = var95;
					//  var10001 = false;
					break;
				}*/
				//stream.write("DATA");
				//stream.write(Integer.reverseBytes(length));
				//stream.write(buffer, offset, length);
				//stream.write( ByteUtils.intToByteArray(read+8));
				// mcon.append("2");
	/*			log.a(stream.isClosed()+"2");
				log.a(read);
				DataOutput d;
				log.a(ByteUtils.concat("DATA".getBytes(), ByteUtils.intToByteArray(read)));
				stream.write("DATA".getBytes());
				stream.write(ByteUtils.intToByteArray(Integer.reverseBytes(read)));
				
				
				//stream.write(ByteUtils.concat("DATA".getBytes(), ByteUtils.intToByteArray(read)));
				log.a(stream.isClosed()+"3");
				if (read == buff.length) {
					stream.write(buff);
				} else {
					byte[] tmp = new byte[read];
					System.arraycopy(buff, 0, tmp, 0, read);
					stream.write(tmp);
					//mcon.append("3");
				}
				stream.write((",0,"+read).getBytes());
				//  mcon.append("4");
				sent += read;
				log.a(sent);
				log.a(read);
				log.a(stream.isClosed()+"l");
				/*final int progress = (int) (sent * 100 / total);
				if (lastProgress != progress) {
					handler.sendMessage(
						handler.obtainMessage(
							Message.INSTALLING_PROGRESS, Message.PUSH_PART, progress));
					lastProgress = progress;
				}*/
		//	}
/*
			stream.write(
				ByteUtils.concat(
					"DONE".getBytes(), ByteUtils.intToByteArray((int) System.currentTimeMillis())));
			//	mcon.append("5");
			log.a("done");
			byte[] res = stream.read();
			// TODO: test if res contains "OKEY" or "FAIL"
			Log.d(Const.TAG, new String(res));

			stream.write(ByteUtils.concat("QUIT".getBytes(), ByteUtils.intToByteArray(0)));
			//	mcon.append("6");
			*/
		
			
			}catch(Exception e){
				log.a(e);
			}
			try {
				//final WritableByteChannel channel = Channels.newChannel((OutputStream)androidDevice);
				String s=remotePath;
				InputStream instance=new FileInputStream(local);
				final int mkid = this.mkid('S', 'E', 'N', 'D');
				final StringBuilder sb = new StringBuilder().append(s).append(",0644");
				//Intrinsics.checkNotNullExpressionValue((Object)channel, "outChannel");
				this.sendRequest(stream,mkid,sb.toString());
				final byte[] array = new byte[adbConnection.getMaxData()-9];
				log.a(adbConnection.getMaxData()-9+"isthemax");
				final int mkid2 = this.mkid('D', 'A', 'T', 'A');
				int i=0;
				while (true) {
					log.a("loop="+i);
					i++;
					int read = instance.read(array);
					if (read == -1) {
						break;
					}
					final ByteBuffer allocate = ByteBuffer.allocate(read + 8);
					allocate.order(ByteOrder.LITTLE_ENDIAN);
					allocate.putInt(mkid2);
					allocate.putInt(read);
					final byte[] copy = Arrays.copyOf(array, read);
					//  Intrinsics.checkNotNullExpressionValue((Object)copy, "copyOf(this, newSize)");
					allocate.put(copy);
					//allocate.flip();
					stream.write(allocate.array());
					log.a("sended"+i);
					
					/* if (function1 == null) {
					 continue;
					 }
					 function1.invoke((Object)(read / (float)n));*/
				}
				log.a("done");
				final int mkid3 = this.mkid('D', 'O', 'N', 'E');
				final ByteBuffer allocate2 = ByteBuffer.allocate(8);
				log.a(0);
				allocate2.order(ByteOrder.LITTLE_ENDIAN);
				allocate2.putInt(mkid3);
				allocate2.putInt((int)(System.currentTimeMillis() / 1000));
				allocate2.flip();
				log.a(1);
				//instance=new FileInputStream(local);
				//stream = adbConnection.open("sync:");
				stream.write(allocate2. array());
				log.a(2);
				final int mkid4 = this.mkid('O', 'K', 'A', 'Y');
				final ByteBuffer allocate3 = ByteBuffer.allocate(8);
				log.a(6);
				allocate3.order(ByteOrder.LITTLE_ENDIAN);
				allocate3.putInt(mkid4);
				allocate3.putInt((int)(System.currentTimeMillis() / 1000));
				allocate3.flip();
				//stream.write(allocate3. array());
				//instance = adbConnect.getInputStream();
				try {
					final InputStream inputStream = instance;
					log.a(3);
					// Intrinsics.checkNotNullExpressionValue((Object)inputStream, "it");
					/*if (this.readStatus(inputStream)) {
						log.a(4+""+readStatus(inputStream));
						//final Unit instance2 = Unit.INSTANCE;
						//  CloseableKt.closeFinally((Closeable)instance, (Throwable)null);
						//instance = (InputStream)Unit.INSTANCE;
						//  CloseableKt.closeFinally((Closeable)androidDevice, (Throwable)null);
						return;
					}
					final StringBuilder sb2 = new StringBuilder();
					sb2.append("Could not push to ");
					sb2.append(s);
					log.a(sb2);
					throw new RuntimeException(sb2.toString());
					*/
				}catch(Exception e){
					log.a(e);
				}
				finally {
					try {}
					finally {
						//instance.close();
						log.a("instance cloce");
						//  CloseableKt.closeFinally((Closeable)instance, (Throwable)s);
					}
				}
			}catch(Exception e){
				log.a(e);
			}
			finally {
				try {}
				finally {
					try{
					//stream.close();
					}catch(Exception e){
						log.a(e);
					}
					log.a("cloce stream");
					// CloseableKt.closeFinally((Closeable)androidDevice, (Throwable)s);
				}
			}
			
			
		}
		private final int mkid(char var1, char var2, char var3, char var4) {
			return var1 | var2 << 8 | var3 << 16 | var4 << 24;
		}
		private final void sendRequest(AdbStream writableByteChannel, int i, String str) throws IOException, InterruptedException {
			byte[] bytes = str.getBytes(Charset.forName( "UTF-8"));
			//Intrinsics.checkNotNullExpressionValue(bytes, "this as java.lang.String).getBytes(charset)");
			ByteBuffer allocate = ByteBuffer.allocate(bytes.length + 8);
			allocate.order(ByteOrder.LITTLE_ENDIAN);
			allocate.putInt(i);
			allocate.putInt(bytes.length);
			allocate.put(bytes);
			allocate.flip();
			writableByteChannel.write(allocate.array());
		}
		private final boolean readStatus(InputStream inputStream) throws IOException {
			byte[] bArr = new byte[4];
			//UtilKt.readExactly(inputStream, bArr, 4);
			try {
				stream = adbConnection.open("sync:");
				byte[] b=stream.read();
				bArr=Arrays.copyOf(b, 4);
			//inputStream.read(bArr, 0, 4);
			//String decodeToString = StringsKt.decodeToString(bArr);
			String decodeToString=new String(bArr,Charset.forName("UTF-8"));
			log.a(decodeToString);
			if (decodeToString.equals( "OKAY")) {
				return true;
			}
			if (decodeToString.equals( "FAIL")) {
				return false;
			}
			} catch (Exception e) {
				log.a(e);
			}
			
			/*String readProtocolString = readProtocolString(inputStream);
			decodeToString = TAG;
			StringBuilder stringBuilder = new StringBuilder("Failed to read status: ");
			stringBuilder.append(readProtocolString);
			Log.e(decodeToString, stringBuilder.toString());*/
			return false;
		}
	}
  public static class ExternalCmdStore {
    private static SharedPreferences sharedPreferences;
    private static String CMD_KEY = "cmd_key";

    private static void initShared(Context context) {
      if (sharedPreferences == null)
        sharedPreferences = context.getSharedPreferences("cmd", Context.MODE_PRIVATE);
    }

    public static void put(Context context, String cmd) {
      initShared(context);
      sharedPreferences.edit().putString(CMD_KEY, cmd).apply();
    }

    public static String get(Context context) {
      initShared(context);
      return sharedPreferences.getString(CMD_KEY, null);
    }
  }
	private final int mkid(char var1, char var2, char var3, char var4) {
		return var1 | var2 << 8 | var3 << 16 | var4 << 24;
	}
	/*public final void push(AndroidDevice var1, InputStream var2, String var3, long var4) {
		Socket var97 = this.adbConnect(var1, "sync:");
		Closeable var10 = (Closeable)var97.getOutputStream();

		Throwable var10000;
		boolean var10001;
		Throwable var98;
		Closeable var99;
		label630: {
			label625: {
				int var8;
				byte[] var12;
				WritableByteChannel var103;
				try {
					var103 = Channels.newChannel((OutputStream)var10);
					var8 = this.mkid('S', 'E', 'N', 'D');
					StringBuilder var11 = new StringBuilder();
					var11.append(var3);
					var11.append(",33152");
					String var104 = var11.toString();
					//Intrinsics.checkNotNullExpressionValue(var103, "outChannel");
					this.sendRequest(var103, var8, var104);
					var12 = new byte[6144];
					var8 = this.mkid('D', 'A', 'T', 'A');
				} catch (Throwable var96) {
					var10000 = var96;
					var10001 = false;
					break label625;
				}

				while(true) {
					int var9;
					try {
						var9 = var2.read(var12);
					} catch (Throwable var94) {
						var10000 = var94;
						var10001 = false;
						break;
					}

					if (var9 == -1) {
						try {
							var8 = this.mkid('D', 'O', 'N', 'E');
							ByteBuffer var100 = ByteBuffer.allocate(8);
							var100.order(ByteOrder.LITTLE_ENDIAN);
							var100.putInt(var8);
							var100.putInt((int)(System.currentTimeMillis() / (long)1000));
							var100.flip();
							var103.write(var100);
							var99 = (Closeable)var97.getInputStream();
							break label630;
						} catch (Throwable var93) {
							var10000 = var93;
							var10001 = false;
							break;
						}
					}

					try {
						ByteBuffer var105 = ByteBuffer.allocate(var9 + 8);
						var105.order(ByteOrder.LITTLE_ENDIAN);
						var105.putInt(var8);
						var105.putInt(var9);
						var105.put(Arrays.copyOf(var12, var9));
						var105.flip();
						var103.write(var105);
					} catch (Throwable var95) {
						var10000 = var95;
						var10001 = false;
						break;
					}

					
				}
			}

			var98 = var10000;

			try {
				throw var98;
			} finally {
				;
			}
		}

		label611: {
			try {
				if (this.readStatus((InputStream)var99)) {
					return;
				}
			} catch (Throwable var92) {
				var10000 = var92;
				var10001 = false;
				break label611;
			}

			label605:
			try {
				StringBuilder var101 = new StringBuilder();
				var101.append("Could not push to ");
				var101.append(var3);
				RuntimeException var102 = new RuntimeException(var101.toString());
				throw var102;
			} catch (Throwable var91) {
				var10000 = var91;
				var10001 = false;
				break label605;
			}
		}

		var98 = var10000;

		
	}
	*/
	
  public static class Install {
    private AdbConnection adbConnection;
    private String remotePath;
    private long installTimeAssumption = 0;

    public Install(AdbConnection adbConnection, String remotePath, long installTimeAssumption) {
      this.adbConnection = adbConnection;
      this.remotePath = remotePath;
      this.installTimeAssumption = installTimeAssumption;
    }

    public void execute(final Handler handler) throws IOException, InterruptedException {
      final AtomicBoolean done = new AtomicBoolean(false);
      try {
        AdbStream stream = adbConnection.open("shell:pm install -r " + remotePath);
        // we assume installation will take installTimeAssumption milliseconds.
        new Thread() {
          @Override
          public void run() {
            int percent = 0;

            while (!done.get()) {
              handler.sendMessage(
                  handler.obtainMessage(
                      MessageOtg.INSTALLING_PROGRESS, MessageOtg.PM_INST_PART, percent));

              if (percent < 95) {
                percent += 1;
                try {
                  Thread.sleep(installTimeAssumption / 100);
                } catch (InterruptedException e) {
                  e.printStackTrace();
                }
              }
            }
          }
        }.start();

        while (!stream.isClosed()) {
          try {
            Log.d(Const.TAG, new String(stream.read()));
          } catch (IOException e) {
            // there must be a Stream Close Exception
            break;
          }
        }
      } finally {
        done.set(true);
        handler.sendMessage(
            handler.obtainMessage(MessageOtg.INSTALLING_PROGRESS, MessageOtg.PM_INST_PART, 100));
      }
    }
  }

  public static class MyAdbBase64 implements AdbBase64 {
    @Override
    public String encodeToString(byte[] data) {
      return Base64.encodeToString(data, Base64.NO_WRAP);
    }
  }
  /*
	public final void push(AndroidDevice var1, InputStream var2, String var3, long var4, Function1<? super Float, Unit> var6) {
		//Intrinsics.checkNotNullParameter(var2, "srcFileStream");
		//Intrinsics.checkNotNullParameter(var3, "destFilePath");
		Socket var10 = this.adbConnect(var1, "sync:");
		Closeable var146 = (Closeable)var10.getOutputStream();

		Throwable var10000;
		label931: {
			int var7;
			WritableByteChannel WritableByteChannel;
			byte[] var12;
			boolean var10001;
			try {
				WritableByteChannel = Channels.newChannel((OutputStream)var146);
				var7 = this.mkid('S', 'E', 'N', 'D');
				StringBuilder var11 = new StringBuilder();
				var11.append(var3);
				var11.append(",33152");
				String var156 = var11.toString();
				//Intrinsics.checkNotNullExpressionValue(var9, "outChannel");
				this.sendRequest(WritableByteChannel, var7, var156);
				var12 = new byte[6144];
				var7 = this.mkid('D', 'A', 'T', 'A');
			} catch (Throwable var145) {
				var10000 = var145;
				var10001 = false;
				break label931;
			}

			while(true) {
				int var8;
				try {
					var8 = var2.read(var12);
				} catch (Throwable var142) {
					var10000 = var142;
					var10001 = false;
					break;
				}

				if (var8 == -1) {
					Closeable var148;
					try {
						var7 = this.mkid('D', 'O', 'N', 'E');
						ByteBuffer var147 = ByteBuffer.allocate(8);
						var147.order(ByteOrder.LITTLE_ENDIAN);
						var147.putInt(var7);
						var147.putInt((int)(System.currentTimeMillis() / (long)1000));
						var147.flip();
						WritableByteChannel.write(var147);
						var148 = (Closeable)var10.getInputStream();
					} catch (Throwable var141) {
						var10000 = var141;
						var10001 = false;
						break;
					}

					label937: {
						label914: {
							try {
								InputStream var152 = (InputStream)var148;
								//Intrinsics.checkNotNullExpressionValue(var152, "it");
								if (this.readStatus(var152)) {
									Unit var150 = Unit.INSTANCE;
									break label914;
								}
							} catch (Throwable var140) {
								var10000 = var140;
								var10001 = false;
								break label937;
							}

							try {
								StringBuilder var154 = new StringBuilder();
								var154.append("Could not push to ");
								var154.append(var3);
								RuntimeException var155 = new RuntimeException(var154.toString());
								throw var155;
							} catch (Throwable var139) {
								var10000 = var139;
								var10001 = false;
								break label937;
							}
						}

						try {
							//CloseableKt.closeFinally(var148, (Throwable)null);
							Unit var151 = Unit.INSTANCE;
						} catch (Throwable var138) {
							var10000 = var138;
							var10001 = false;
							break;
						}

						CloseableKt.closeFinally(var146, (Throwable)null);
						return;
					}

					Throwable var153 = var10000;

					try {
						throw var153;
					} finally {
						try {
							CloseableKt.closeFinally(var148, var153);
						} catch (Throwable var136) {
							var10000 = var136;
							var10001 = false;
							break;
						}
					}
				}

				try {
					ByteBuffer var157 = ByteBuffer.allocate(var8 + 8);
					var157.order(ByteOrder.LITTLE_ENDIAN);
					var157.putInt(var7);
					var157.putInt(var8);
					byte[] var13 = Arrays.copyOf(var12, var8);
					//Intrinsics.checkNotNullExpressionValue(var13, "copyOf(this, newSize)");
					var157.put(var13);
					var157.flip();
					WritableByteChannel.write(var157);
				} catch (Throwable var144) {
					var10000 = var144;
					var10001 = false;
					break;
				}

				if (var6 != null) {
					try {
						var6.invoke((float)var8 / (float)var4);
					} catch (Throwable var143) {
						var10000 = var143;
						var10001 = false;
						break;
					}
				}
			}
		}

		Throwable var149 = var10000;

		try {
			throw var149;
		} finally {
			//CloseableKt.closeFinally(var146, var149);
		}
	}*/
	/*public void npush(InputStream instance,String s) throws IOException{
		try {
            final WritableByteChannel channel = Channels.newChannel((OutputStream)androidDevice);
            final int mkid = this.mkid('S', 'E', 'N', 'D');
            final StringBuilder sb = new StringBuilder();
            sb.append(s);
            sb.append(",33152");
            final String string = sb.toString();
            //Intrinsics.checkNotNullExpressionValue((Object)channel, "outChannel");
            this.sendRequest(channel, mkid, string);
            final byte[] array = new byte[6144];
            final int mkid2 = this.mkid('D', 'A', 'T', 'A');
            while (true) {
                final int read = instance.read(array);
                if (read == -1) {
                    break;
                }
                final ByteBuffer allocate = ByteBuffer.allocate(read + 8);
                allocate.order(ByteOrder.LITTLE_ENDIAN);
                allocate.putInt(mkid2);
                allocate.putInt(read);
                final byte[] copy = Arrays.copyOf(array, read);
				//  Intrinsics.checkNotNullExpressionValue((Object)copy, "copyOf(this, newSize)");
                allocate.put(copy);
                allocate.flip();
                channel.write(allocate);
				/* if (function1 == null) {
				 continue;
				 }
				 function1.invoke((Object)(read / (float)n));*/
    /*        }
            final int mkid3 = this.mkid('D', 'O', 'N', 'E');
            final ByteBuffer allocate2 = ByteBuffer.allocate(8);
            allocate2.order(ByteOrder.LITTLE_ENDIAN);
            allocate2.putInt(mkid3);
            allocate2.putInt((int)(System.currentTimeMillis() / 1000));
            allocate2.flip();
            channel.write(allocate2);
            instance = adbConnect.getInputStream();
            try {
                final InputStream inputStream = instance;
				// Intrinsics.checkNotNullExpressionValue((Object)inputStream, "it");
                if (this.readStatus(inputStream)) {
                    //final Unit instance2 = Unit.INSTANCE;
					//  CloseableKt.closeFinally((Closeable)instance, (Throwable)null);
                    //instance = (InputStream)Unit.INSTANCE;
					//  CloseableKt.closeFinally((Closeable)androidDevice, (Throwable)null);
                    return;
                }
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Could not push to ");
                sb2.append(s);
                throw new RuntimeException(sb2.toString());
            }
            finally {
                try {}
                finally {
					//  CloseableKt.closeFinally((Closeable)instance, (Throwable)s);
                }
            }
        }
        finally {
            try {}
            finally {
				// CloseableKt.closeFinally((Closeable)androidDevice, (Throwable)s);
            }
        }
	}
    public final void push(AndroidDevice androidDevice, InputStream instance, final String s, final long n, final Function1<? super Float, Unit> function1) throws IOException {
        //Intrinsics.checkNotNullParameter((Object)instance, "srcFileStream");
        //Intrinsics.checkNotNullParameter((Object)s, "destFilePath");
        final Socket adbConnect = this.adbConnect(androidDevice, "sync:");
        androidDevice = (AndroidDevice)adbConnect.getOutputStream();
        try {
            final WritableByteChannel channel = Channels.newChannel((OutputStream)androidDevice);
            final int mkid = this.mkid('S', 'E', 'N', 'D');
            final StringBuilder sb = new StringBuilder();
            sb.append(s);
            sb.append(",33152");
            final String string = sb.toString();
            //Intrinsics.checkNotNullExpressionValue((Object)channel, "outChannel");
            this.sendRequest(channel, mkid, string);
            final byte[] array = new byte[6144];
            final int mkid2 = this.mkid('D', 'A', 'T', 'A');
            while (true) {
                final int read = instance.read(array);
                if (read == -1) {
                    break;
                }
                final ByteBuffer allocate = ByteBuffer.allocate(read + 8);
                allocate.order(ByteOrder.LITTLE_ENDIAN);
                allocate.putInt(mkid2);
                allocate.putInt(read);
                final byte[] copy = Arrays.copyOf(array, read);
              //  Intrinsics.checkNotNullExpressionValue((Object)copy, "copyOf(this, newSize)");
                allocate.put(copy);
                allocate.flip();
                channel.write(allocate);
               /* if (function1 == null) {
                    continue;
                }
                function1.invoke((Object)(read / (float)n));*/
   /*         }
            final int mkid3 = this.mkid('D', 'O', 'N', 'E');
            final ByteBuffer allocate2 = ByteBuffer.allocate(8);
            allocate2.order(ByteOrder.LITTLE_ENDIAN);
            allocate2.putInt(mkid3);
            allocate2.putInt((int)(System.currentTimeMillis() / 1000));
            allocate2.flip();
            channel.write(allocate2);
            instance = adbConnect.getInputStream();
            try {
                final InputStream inputStream = instance;
               // Intrinsics.checkNotNullExpressionValue((Object)inputStream, "it");
                if (this.readStatus(inputStream)) {
                    //final Unit instance2 = Unit.INSTANCE;
                  //  CloseableKt.closeFinally((Closeable)instance, (Throwable)null);
                    //instance = (InputStream)Unit.INSTANCE;
                  //  CloseableKt.closeFinally((Closeable)androidDevice, (Throwable)null);
                    return;
                }
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Could not push to ");
                sb2.append(s);
                throw new RuntimeException(sb2.toString());
            }
            finally {
                try {}
                finally {
                  //  CloseableKt.closeFinally((Closeable)instance, (Throwable)s);
                }
            }
        }
        finally {
            try {}
            finally {
               // CloseableKt.closeFinally((Closeable)androidDevice, (Throwable)s);
            }
        }
    }
	private final boolean readStatus(InputStream inputStream) throws IOException {
        byte[] bArr = new byte[4];
        //UtilKt.readExactly(inputStream, bArr, 4);
		inputStream.read(bArr,0,4);
        //String decodeToString = StringsKt.decodeToString(bArr);
		String decodeToString=new String(bArr,Charset.forName("UTF-8"));
        if (decodeToString.equals( "OKAY")) {
            return true;
        }
        if (decodeToString.equals( "FAIL")) {
            return false;
        }
        String readProtocolString = readProtocolString(inputStream);
        decodeToString = TAG;
        StringBuilder stringBuilder = new StringBuilder("Failed to read status: ");
        stringBuilder.append(readProtocolString);
        Log.e(decodeToString, stringBuilder.toString());
        return false;
    }
	private final void sendRequest(WritableByteChannel writableByteChannel, int i, String str) throws IOException {
        byte[] bytes = str.getBytes(Charset.forName( "UTF-8"));
        //Intrinsics.checkNotNullExpressionValue(bytes, "this as java.lang.String).getBytes(charset)");
        ByteBuffer allocate = ByteBuffer.allocate(bytes.length + 8);
        allocate.order(ByteOrder.LITTLE_ENDIAN);
        allocate.putInt(i);
        allocate.putInt(bytes.length);
        allocate.put(bytes);
        allocate.flip();
        writableByteChannel.write(allocate);
    }*/
}
